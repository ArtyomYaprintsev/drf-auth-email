# SPDX-FileCopyrightText: 2023-present ArtyomYaprintsev <yapryntsev.a02@mail.ru>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.2"
