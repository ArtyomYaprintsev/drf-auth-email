# drf-auth-email

[![PyPI - Version](https://img.shields.io/pypi/v/drf-auth-email.svg)](https://pypi.org/project/drf-auth-email)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/drf-auth-email.svg)](https://pypi.org/project/drf-auth-email)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install drf-auth-email
```

## License

`drf-auth-email` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
