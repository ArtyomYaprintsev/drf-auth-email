# Check that settings user is drf_auth_email.user.abstracts.AbstractUser instance (for verified and unique email)
# Check that emails are drf_auth_email.user.email.CodeVerifyEmail instances
# Check that the user model has an required email field

# For views checks that user has an unique email field and boolean is_verified

# 'rest_framework' and 'rest_framework.authtoken' inside INSTALLED APPS

# check that all used templates exists
